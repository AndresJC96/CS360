package com.example.cs360projecttwo;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class GridActivity extends AppCompatActivity {

    DatabaseHelper db;
    ListView listView;
    Button btnAddItem, btnOpenSms;

    ArrayList<String> itemList;
    ArrayList<Integer> itemIds;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        db = new DatabaseHelper(this);
        listView = findViewById(R.id.listView);
        btnAddItem = findViewById(R.id.btnAddItem);
        btnOpenSms = findViewById(R.id.btnOpenSms);

        loadItems();

        btnAddItem.setOnClickListener(v -> showAddItemDialog());

        btnOpenSms.setOnClickListener(v -> {
            startActivity(new Intent(GridActivity.this, SmsActivity.class));
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            int itemId = itemIds.get(position);
            String currentName = itemList.get(position);
            showUpdateItemDialog(itemId, currentName);
        });

        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            int itemId = itemIds.get(position);
            boolean deleted = db.deleteItem(itemId);

            if (deleted) {
                Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                loadItems();
            } else {
                Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
            }
            return true;
        });
    }

    private void loadItems() {
        itemList = new ArrayList<>();
        itemIds = new ArrayList<>();

        Cursor cursor = db.getAllItems();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("item_id"));
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow("item_name"));

                itemIds.add(id);
                itemList.add(itemName);
            } while (cursor.moveToNext());
        }

        cursor.close();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, itemList);
        listView.setAdapter(adapter);
    }

    private void showAddItemDialog() {
        EditText editText = new EditText(this);

        new AlertDialog.Builder(this)
                .setTitle("Add Item")
                .setView(editText)
                .setPositiveButton("Add", (dialog, which) -> {
                    String itemName = editText.getText().toString().trim();

                    if (!itemName.isEmpty()) {
                        boolean inserted = db.addItem(itemName);
                        if (inserted) {
                            Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
                            loadItems();
                        } else {
                            Toast.makeText(this, "Insert failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showUpdateItemDialog(int itemId, String currentName) {
        EditText editText = new EditText(this);
        editText.setText(currentName);

        new AlertDialog.Builder(this)
                .setTitle("Update Item")
                .setView(editText)
                .setPositiveButton("Update", (dialog, which) -> {
                    String updatedName = editText.getText().toString().trim();

                    if (!updatedName.isEmpty()) {
                        boolean updated = db.updateItem(itemId, updatedName);
                        if (updated) {
                            Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();
                            loadItems();
                        } else {
                            Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}