package com.example.cs360projecttwo;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    TextView textSmsStatus;
    Button btnRequestSms, btnSendSms;

    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    textSmsStatus.setText("SMS permission granted");
                    Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show();
                } else {
                    textSmsStatus.setText("SMS permission denied. App still works without SMS.");
                    Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        textSmsStatus = findViewById(R.id.textSmsStatus);
        btnRequestSms = findViewById(R.id.btnRequestSms);
        btnSendSms = findViewById(R.id.btnSendSms);

        updatePermissionStatus();

        btnRequestSms.setOnClickListener(v -> {
            requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        });

        btnSendSms.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                sendSmsAlert();
            } else {
                textSmsStatus.setText("SMS permission denied. Cannot send message.");
                Toast.makeText(this, "Grant permission first", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updatePermissionStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            textSmsStatus.setText("SMS permission already granted");
        } else {
            textSmsStatus.setText("SMS permission not granted");
        }
    }

    private void sendSmsAlert() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("+15555555555", null,
                    "Inventory alert: this is a test SMS from CS360ProjectTwo.",
                    null, null);

            Toast.makeText(this, "Test SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed to send", Toast.LENGTH_SHORT).show();
        }
    }
}